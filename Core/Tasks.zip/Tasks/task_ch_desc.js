var task_description_data = {
    "Description": "This task aims at interpreting a medical text",
    "Instructions": "For each unit, two labels are provided; the first is a chemical substance and the second is a disease name. A short text extracted from scientific article is also provided" +
    "your task is to read the text and decide whether there is a direct, indirect or no relation between the substance and the disease."
}