var task_description_data = {
    "Description": "This task aims at judging the relevance of tweets in a disaster context",
}