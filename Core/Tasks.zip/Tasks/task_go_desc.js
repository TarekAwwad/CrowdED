var task_description_data = {
    "Description": "This task aims at labeling political tweets.",
    "Instructions": "For each unit you need to determine the concerned candidate, the sentiment of the tweet as well as it is subject"

}