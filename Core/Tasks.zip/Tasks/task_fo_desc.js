var task_description_data = {
    "Description": "This task aims at analysing american football scenarios."
    ,
    "Instructions": "For each unit, read and analyse the scenario provided in the blue box. Your goal is to pick among the available options the decision that is the best according to you."
}