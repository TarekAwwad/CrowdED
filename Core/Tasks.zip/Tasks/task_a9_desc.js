var task_description_data = {
    "Description": "This task aims at recognizing sports in images."
    ,
    "Instructions": "For each unit, look at the provided image(s) and read the text. Your goal is to decide whether the provided images depicts the sport described in the text :" +
    "<br> - If so, you need to fill in the text box the part of the image (object, place, ...) that proves your choice." +
    "<br> - If not, fill in the text box the name of the sport/activity shown in the image."
    ,
    "Example": ""
    ,
    "Notes": "Hover on the picture to zoom in"
}
