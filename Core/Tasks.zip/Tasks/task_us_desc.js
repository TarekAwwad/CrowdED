var task_description_data = {
    "Description": "Determining the relevance and the positivity of an article headline"
    ,
    "Instructions": "In each of these units a new article headline is provided. Your goal is to decide whether it provides an indication of the U.S. economy's health, and then to rate the positivity of this article from 1 to 9 (1 being very negative and 9 being very positive) "
}