var task_data = {
    "id": "go",
    "type": "dd_mm",
    "Task_1183": {
        "name": "HIT1183",
        "id": "Task-1183",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @rumpfshaker: \"We have to make our country great again and I will do that!\" Donald Trump, who still can't quite explain HOW. #gopdebate "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_1317": {
        "name": "HIT1317",
        "id": "Task-1317",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " #TPFA @TPFA_KathyA_1&lt;=Declined 2 comment Can't locate \"Proe\" $100 says ants didn't watch #GOPDebate @realDonaldTrump http://t.co/2VgoCBDpyX "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_3584": {
        "name": "HIT3584",
        "id": "Task-3584",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @GetUpStandUp2: The vouchers create conditions of corruption, @jebbush.  They have have re-segregated schools! #BATSask #GOPdebate http:??_ "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_3706": {
        "name": "HIT3706",
        "id": "Task-3706",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " My #GOPDebate review:_??__??-Bush, Kasich; Eh-Huckabee, Christie; OK, wanted more-Paul, Cruz, Rubio; _??_??-Trump, Walker, Carson. Overall-good group "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_3439": {
        "name": "HIT3439",
        "id": "Task-3439",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " Thanks @EAT24 and Donald Trump! Just got a Pepperoni Roll &amp; a root beer for $7.50 + tip. #yay #GOPDebates #Eat24 "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_221": {
        "name": "HIT221",
        "id": "Task-221",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " It seems like Ben Carson did a good job, but lacks the insights and depth of knowledge needed for a President #GOPDebates "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_163": {
        "name": "HIT163",
        "id": "Task-163",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @ElizabethND04: Wow. Awesome Dr. Carson race answer! @RealBenCarson #GOPDebate #FOXNEWSDEBATE #FoxNews #FoxDebate @FoxNews #FNC  https:/??_ "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_145": {
        "name": "HIT145",
        "id": "Task-145",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " Ben Carson &amp; Marco Rubio were biggest winners of #GOPDebate, Donald Trump &amp; Rand Paul biggest losers. https://t.co/qUwbtdThms "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_1504": {
        "name": "HIT1504",
        "id": "Task-1504",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " is suffering from an existential crisis.  Is there a need for @WallyWeeins when we have a @RealDonaldTrump?  #GOPDebate #GOP2016 "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_625": {
        "name": "HIT625",
        "id": "Task-625",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @RWSurferGirl: Is it just me or does anyone else want to punch Chris Wallace in the face? #GOPDebate  #GOPDebates _??_??? "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_2612": {
        "name": "HIT2612",
        "id": "Task-2612",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @Samstwitch: Wow, everybody's tweeting about @FoxNews', @megynkelly's bad treatment of @realDonaldTrump and #GOPDebates!  Agreed! "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_12": {
        "name": "HIT12",
        "id": "Task-12",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @DonnieWahlberg: Like Ben Carsons brain. Mike Huckabees heart. Marco Rubios soul. Chris Christies fight. John Kasichs hope. Add Carly Fi??_ "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_2574": {
        "name": "HIT2574",
        "id": "Task-2574",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @Samstwitch: Wow, everybody's tweeting about @FoxNews', @megynkelly's bad treatment of @realDonaldTrump and #GOPDebates!  Agreed! "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_9": {
        "name": "HIT9",
        "id": "Task-9",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @AndrewHClark: .@GayPatriot's takeaway from last night: \"America Doesn't Deserve Ben Carson.\" http://t.co/kjGFYYpcTe #GOPDebate "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women\'s Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_43": {
        "name": "HIT43",
        "id": "Task-43",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " I honestly really want to hear what Ben Carson has to say #GOPDebate "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_1654": {
        "name": "HIT1654",
        "id": "Task-1654",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " Political correctness... Ain't nobody got time for that! #GOPDebate #Trump "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_3597": {
        "name": "HIT3597",
        "id": "Task-3597",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @TheBaxterBean: Jeb Bush's Attack on Public Schools Diverts Public Money To Private Corporations http://t.co/xOnRLY0Ece #GOPDebate http:??_ "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_192": {
        "name": "HIT192",
        "id": "Task-192",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @DabneyPorte: Ohhhh #BenCarson. Your honesty and beautiful soul make us love you #gopdebate "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_1815": {
        "name": "HIT1815",
        "id": "Task-1815",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " Trump schooling Chris Wallace reminded me of that scene in Back To School where Dangerfield schooled the nerdy biz professor. #GOPDebate "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_1297": {
        "name": "HIT1297",
        "id": "Task-1297",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @ilirprogri: @FoxNews @lizpeek @realDonaldTrump is highly adaptable! He will improve more than anyone else from the #GOPDebate #Inconsis??_ "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_1943": {
        "name": "HIT1943",
        "id": "Task-1943",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @MistiTweets: I Am A Woman &amp; Not Offended By @realDonaldTrump  @megynkelly Needs To NOT Say ALL Women Rather Sensitive Liberal Women! #G??_ "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_3700": {
        "name": "HIT3700",
        "id": "Task-3700",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @Brizzandonn: \"let's pay teachers less while somehow making them teach better.\" - jeb bush #GOPDebate "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_2241": {
        "name": "HIT2241",
        "id": "Task-2241",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " #GOPDebate winners: Trump, Cruz, Carson, Kasich, Huckabee, Fiorina #POTUS #Trump2016 #republicans "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_3552": {
        "name": "HIT3552",
        "id": "Task-3552",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " How do you earn a Jeb? http://t.co/JKGx2Ojrwi #GOPDebate "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_358": {
        "name": "HIT358",
        "id": "Task-358",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @InfamousPCG77: Here's what they think about you, Ben Carson!!!! THEY DON'T LOVE YOU!!!! #GOPDebates http://t.co/1yQzZzEDNN "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_3988": {
        "name": "HIT3988",
        "id": "Task-3988",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @RWSurferGirl: Jeb Bush reminds me of elevator music. You hear it but you don't listen. _??_??? #GOPDebate  #GOPDebates "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_3715": {
        "name": "HIT3715",
        "id": "Task-3715",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " Jeb Bush underperforms at the #GOPDebate http://t.co/P9AuvS7Egn by jonward11 http://t.co/VvQ2JGN9bI "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_1195": {
        "name": "HIT1195",
        "id": "Task-1195",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @ChadFromStL: .@realDonaldTrump should answer @jdharm's hard-hitting question from last night's #GOPDebate @sternshow @HowardStern http:??_ "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_33": {
        "name": "HIT33",
        "id": "Task-33",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " America in 2015 Doesn't Deserve Ben Carson http://t.co/pe4NrDzXoG via @ijreview @gop #gopdebate @realbencarson "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_2294": {
        "name": "HIT2294",
        "id": "Task-2294",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " Trump responds to @megynkelly question on misogyny with more misogyny #GOPDebate http://t.co/Pb5cgmO3V5 http://t.co/8PFdgltNAW "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_3687": {
        "name": "HIT3687",
        "id": "Task-3687",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @PruneJuiceMedia: Jeb needs a reality check that it was HIS brother who messed up Iraq. Don??t put Obama on that. #GOPDebate "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_3712": {
        "name": "HIT3712",
        "id": "Task-3712",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " #GOPDebate #JebBush wants hopeful optimistic message. Like war with Iran, attacking Social Security, #WarOnWomen tactics, voter suppression "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_3729": {
        "name": "HIT3729",
        "id": "Task-3729",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @SeeThroughFruit: Jeb Bush more like please just stop #GOPDebates "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_1": {
        "name": "HIT1",
        "id": "Task-1",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " Deer in the headlights RT @lizzwinstead: Ben Carson, may be the only brain surgeon who has performed a lobotomy on himself. #GOPDebate "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_316": {
        "name": "HIT316",
        "id": "Task-316",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " I have a friend that looks and talks just like Ben Carson, it's ruining the debate for me. #GOPDebates "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_3679": {
        "name": "HIT3679",
        "id": "Task-3679",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @JebBush: Hillary Clinton and Barack Obama are wrong. We can grow this economy again. http://t.co/aViaq6Flkf #GOPDebate "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_3608": {
        "name": "HIT3608",
        "id": "Task-3608",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " Not sure about Jeb Bush, but one thing I know for sure is that he didn't help himself w/last nights #GOPDebate. @OutnumberedFNC @ericbolling "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_276": {
        "name": "HIT276",
        "id": "Task-276",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " I can't help but think Dr. Carson has been hoping his \"Gifted Hands\" can make a way for his flailing mouth. #GOPDebates "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_3957": {
        "name": "HIT3957",
        "id": "Task-3957",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @jordiemojordie: Jeb!, Planned Parenthood is NOT just about abortions: they provide contraception and women's healthcare to low income w??_ "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_1229": {
        "name": "HIT1229",
        "id": "Task-1229",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @megynkelly: .@realDonaldTrump:  If it weren??t for me you wouldn??t even be talking about illegal immigration #GOPDebate "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_1177": {
        "name": "HIT1177",
        "id": "Task-1177",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @RavingRaver: My response when @megynkelly tried to call @realDonaldTrump a sexist: \"CAN'T STUMP THE TRUMP!\" #GOPDebate "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_83": {
        "name": "HIT83",
        "id": "Task-83",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @pattonoswalt: Dear Dr. Ben Carson: A CANTICLE FOR LEIBOWITZ is not a hopeful vision of the future. #tithing #GOPDebate "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_3594": {
        "name": "HIT3594",
        "id": "Task-3594",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @TheBaxterBean: Jeb Bush Worked For Cuban Officer That Plead Guilty To Defrauding Gov't of Millions http://t.co/xMO3SnlW1p #GOPDebate ht??_ "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_260": {
        "name": "HIT260",
        "id": "Task-260",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " Is that Ben Carson or Johnny Carson? #GOPDebates "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_107": {
        "name": "HIT107",
        "id": "Task-107",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @GreeneHunter: Ben killed it tonight at the Gop Primary Debate!  #GOPDebate  #Carson16 #RunBenRun "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_93": {
        "name": "HIT93",
        "id": "Task-93",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @namenzie: Safe to say every person of color knows this. We usually aren't the ones who need convincing. #BenCarson #GOPDebate http://t.??_ "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_3633": {
        "name": "HIT3633",
        "id": "Task-3633",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @metzgr: .@JebBush has a distinct @LeoMcGarry-ness to him in this pic from @nytimes, so... #Winner #GOPDebate http://t.co/KoLwWwgdP1 "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_2699": {
        "name": "HIT2699",
        "id": "Task-2699",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @RWSurferGirl: Ask Trump a legitimate question. Look at Wallace's face when Trump nails it. _??_??? #GOPDebate  #GOPDebates "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_1851": {
        "name": "HIT1851",
        "id": "Task-1851",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @tamaraleighllc: Disappointed. @megynkelly was my media #girlcrush &amp;after #GOPDebate think #WeAreOnABreak @FoxNews @realDonaldTrump  htt??_ "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_63": {
        "name": "HIT63",
        "id": "Task-63",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @AnneBayefsky: .@RealBenCarson: Skin &amp; hair don??t make people who they are. As a neurosurgeon, I operate on who they are. #GOPDebate "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_3913": {
        "name": "HIT3913",
        "id": "Task-3913",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @PuestoLoco: .@cenkuygur  Cancel primaries. Fox Party set up &amp; anointed their man Jeb Bush #GOPDebates #CantTrustABush #morningjoe http:??_ "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_792": {
        "name": "HIT792",
        "id": "Task-792",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " So who watched the GOP Debate last night and saw Trump #DonaldTrump #GOPDebate @realDonaldTrump #TrumpForPresident "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_3174": {
        "name": "HIT3174",
        "id": "Task-3174",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @RWSurferGirl: You would never know @realDonaldTrump  is the frontrunner from watching this debate. _??_??? #GOPDebate  #GOPDebates "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_1174": {
        "name": "HIT1174",
        "id": "Task-1174",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @Sleevetalkshow: @realDonaldTrump's incivility &amp; arrogance continues after @FoxNews #GOPDebate. http://t.co/nXoWLLfsIb http://t.co/oQawD??_ "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_1694": {
        "name": "HIT1694",
        "id": "Task-1694",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @FreedomTexasMom: I'd say #Trump #Cruz #Carson. #GOPDebate  https://t.co/johkjZLjQR "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_292": {
        "name": "HIT292",
        "id": "Task-292",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " When Ben Carson  talks about race. #GOPDebates http://t.co/noxpKanwSX "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_870": {
        "name": "HIT870",
        "id": "Task-870",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @ChadHastyRadio: Really, the only people who seem upset with @BretBaier &amp; @megynkelly &amp; FOX are the people who backed Trump. #GOPDebate "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_817": {
        "name": "HIT817",
        "id": "Task-817",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " Maybe if we should paying attention to every little thing #DonaldTrump sez....he's not a novelty anymore!  #GOPDebate #GOPClownCar "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_3519": {
        "name": "HIT3519",
        "id": "Task-3519",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @ImmigranNacion: @JebBush #GOPDebate #USA, seriously, would you vote for any of these CLOWNS? We NEED #CIRNow #AINF #TNTVote http://t.co??_ "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_1544": {
        "name": "HIT1544",
        "id": "Task-1544",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @imoore8904: Trump supporters tee hee &amp; laugh when he insults everyone under the sun. Cry foul when @megynkelly calls him on his shit. #??_ "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_1644": {
        "name": "HIT1644",
        "id": "Task-1644",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " So disappointed @realDonaldTrump never got to answer the God question! #GOPDebate "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
    "Task_3718": {
        "name": "HIT3718",
        "id": "Task-3718",
        "order": " ",
        "text": "",
        "mm": "",
        "tt": {"0": " RT @RedStateMojo: **DRUDGE POLL** Jeb Bush Confirmed as Pathetic, Near Last. #GOPDebate #tcot https://t.co/9vxEIqxjfE "},
        "op": {
            "op0": {
                "op-text": " Which candidate is mentioned in the tweet above ",
                "0": " Ben Carson ",
                "1": " Chris Christie ",
                "2": " Donald Trump ",
                "3": " Jeb Bush "
            },
            "op1": {
                "op-text": " What sentiment does this tweet invoke ? ",
                "0": " Negative ",
                "1": " Neutral ",
                "2": " Positive "
            },
            "op2": {
                "op-text": " Which subject is this tweet about ? ",
                "0": " Abortion ",
                "1": " Foreign Policy ",
                "2": " FOX News or Moderators ",
                "3": " Gun Control ",
                "4": " Healthcare (including Medicare) ",
                "5": " Immigration ",
                "6": " Jobs and Economy ",
                "7": " LGBT issues ",
                "8": " Racial issues ",
                "9": " Religion ",
                "10": " Women's Issues (not abortion though) ",
                "11": " LGBT issues ",
                "12": " None of the above "
            }
        },
        "ft": ""
    },
}